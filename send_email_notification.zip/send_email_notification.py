import json, boto3
import os

SNS_TOPIC_ARN = os.environ.get('topic_arn')

snsClient = boto3.client('sns', region_name="us-east-1")

def lambda_handler(event, context):
    print("Input event : ", event)
    try:
        for record in event['Records']:
            serverDetails = record['dynamodb'].get('NewImage', None)
            if serverDetails:
                cpu = int(record['dynamodb']['NewImage']['CPU']['S'])
                memory = int(record['dynamodb']['NewImage']['Memory']['S'])
                
                if (cpu > 60) or (memory > 75):
                    servername = record['dynamodb']['NewImage']['ServerName']['S']
                    location = record['dynamodb']['NewImage']['ServerLocation']['S']
                    
                    email_message = "Server : {} at location : {} is at Critical state. CPU Utilization : {} and Memory : {}".format(
                        servername, location, cpu, memory
                        )
                    
                    # Send message to SNS
                    try:
                        snsClient.publish(
                            TopicArn = SNS_TOPIC_ARN,
                            Message = email_message,
                            Subject = 'Server Alert!',
                            MessageStructure = 'html'
                        )
                    except Exception as e:
                        print(e)
    except Exception as e:
        print("Get data failed : ", e)
