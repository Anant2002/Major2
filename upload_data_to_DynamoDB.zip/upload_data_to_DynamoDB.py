import boto3
import json
import csv

TABLE_NAME = "store_server_details"


#Client connection to S3 and DynamoDB
s3Client = boto3.client("s3", region_name = "us-east-1")
dynamodbClient = boto3.resource("dynamodb", region_name = "us-east-1")
#Table Name
table = dynamodbClient.Table(TABLE_NAME)

def lambda_handler(event, context):
    #Read bucket and object name from event
    try:
        #S3 bucket and csv file name
        bucket_name = event['Records'][0]['s3']['bucket']['name']
        s3_file_name = event['Records'][0]['s3']['object']['key']
        #Read CSV file form S3 Bucket
        try:
            resp = s3Client.get_object(Bucket=bucket_name,Key=s3_file_name)
            #print(resp)
            data = resp['Body'].read().decode("utf-8").split("\n")
            #print(data)
            csv_reader = csv.reader(data, delimiter=',', quotechar='"')
            #print(csv_reader)
            
            firstrecord=True
            for stud in csv_reader:
                if firstrecord:
                    firstrecord = False
                    continue
                # add data to dynamodb Table
                try:
                    table.put_item(
                        Item = {
                            "ID"                 : stud[0],
                            "CPU"             : stud[1],
                            "Memory"           : stud[2],
                            "ServerLocation"            : stud[3],
                            "ServerName"               : stud[4]
                        }
                    )
                except Exception as e:
                    print("End of file")
            return {
                'statusCode': 200,
                'body': json.dumps("File upload success")
            }
        except Exception as e:
            print("Read file from S3 bucket failed because ", e)
            return {
                'statusCode': 500,
                'body': json.dumps("S3 file Read failed")
            }
    except Exception as e:
        print("Client connection to S3 or DynamoDB failed because ", e)
        return {
            'statusCode': 500,
            'body': json.dumps("Client error")
        }